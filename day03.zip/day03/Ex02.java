package day03;
import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("시간 입력 > ");
		int time = scan.nextInt();
		int hour = (time / 60) / 60;
		int minute = (time / 60) % 60;
		int second = time % 60;
		
		System.out.println("입력된 시간은 "+hour+"시간 "+minute+"분 "+second+"초입니다.");
	
		scan.close();
	}

}
