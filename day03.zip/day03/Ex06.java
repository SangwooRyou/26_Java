package day03;

import java.util.Scanner;

public class Ex06 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		// id, pwd 초기화
		String id = "Sangwoo", pwd = "1234";
		
		System.out.print("ID를 입력하세요 > ");
		String myId = scan.next();
		System.out.print("비밀번호를 입력하세요 > ");
		String myPwd = scan.next();
		
//		상세 검증 : 중첩 제어문
//		if(myId.equals(id)) {
//			if(myPwd.equals(myPwd)) {
//				System.out.println("로그인 성공");
//			}
//			else {
//				System.out.println("비밀번호가 틀렸습니다.");
//			}
//		}
//		else {
//			System.out.println("아이디가 틀렸거나 존재하지 않습니다.");
//		}
		
		if(myId.equals(id) && myPwd.equals(pwd)) {
			System.out.println("로그인 성공");
		}
		else {
			System.out.println("로그인 실패");
		}
		
		scan.close();
	}

}
