package day03;
import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("값을 입력하시오. > ");
		int num = scan.nextInt();
		int n = num % 2;
		String result = (n == 0) ? "짝수" : "홀수";
		
		System.out.println(num+"은/는 "+result+"입니다.");
		
		scan.close();
	}

}
