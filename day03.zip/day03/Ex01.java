package day03;
import java.util.Scanner;

public class Ex01 {
	public static void main(String[] args) {
		// 변수 선언 : 메모리 공간 할당
		int age;
		String name = new String();
		
		// 변수 초기화 : 쓰레기 값 버리기
		age = 20;
		name = "류상우";
		
		System.out.println("나이 : " + age);
		System.out.println("이름 : " + name);
		
		// Scanner 객체 생성 : scan 객체 재사용 (w. next)
		Scanner scan = new Scanner(System.in);
		System.out.print("나이를 입력하세요 > ");
		age = scan.nextInt();
		System.out.print("이름을 입력하세요 > ");
		name = scan.next(); // next vs nextLine : 글자만 -> next, 공백 포함 -> nextLine
		
		double height, weight;
		System.out.print("키를 입력하세요 > ");
		height = scan.nextDouble();
		System.out.print("몸무게를 입력하세요 > ");
		weight = scan.nextDouble();
		
		System.out.print("거주지 입력 > ");
		String city = scan.next();
		System.out.print("독신 여부 입력 > ");
		boolean single = scan.nextBoolean();
		
		System.out.println("입력된 나이 : " + age);
		System.out.println("입력된 이름 : " + name);		
		System.out.println("입력된 키 : " + height);
		System.out.println("입력된 몸무게 : " + weight);		
		System.out.println("입력된 도시 : " + city);
		System.out.println("독신 유무 : " + single);	
		
		scan.close();
	}

}
