package day07;

public class Person {
	// field (variable)
	public static String name;
	int age;
	char abc;
	
	// 데이터 은닉
	private String addr;
	
	// default constructor : 클래스 이름과 동일한 메소드, 객체 생성 시 호출.
	// 역할 : 변수 초기화
	public Person() {
		name = "홍길동";
		age = 20;
		abc = 'A';
		System.out.println("객체 생성 완료");
	}
	
	public static String getName() {
		return name;
	}
	
	// method
	public void 밥먹기() {
		System.out.println("밥먹기");
	}
	
	public void 운동하기(String 종목) {
		System.out.println(종목 + "을(를) 합니다.");
	}
}
