package day07;

// Circle
class Circle{
	public int radius;
	public String name;
	
	// 기본 생성자
	Circle(){ 
//		radius = 10;
//		name = "";
		this(0, "");
	}
	
	Circle(int n){
		this(n, "불고기 피자");
	}
	
	// 인자(매개변수 2개) 생성자
	public Circle(int r, String n) {
		radius = r;
		name = n;
	}
	
	public double getArea() {
		return 3.14 * radius * radius;
	}
}

public class Pizza {
	public static void main(String[] args) {
		// 1. 레퍼런스 변수 pizza 선언.
		Circle pizza;
		// 2. Circle 객체 선언.
		pizza = new Circle();
		// 3. 피자의 반지름 10으로 설정.
		// pizza.radius = 10;
		// 4. 피자 이름 불고기 피자로 변경.
		// pizza.name = "불고기 피자";
		// 5. 피자의 면적 메소드 호출하여 알아내기. 
		System.out.println(pizza.getArea());
		
		Circle pizza2;
		pizza2 = new Circle(15, "치즈피자");

		System.out.println(pizza2.name);
		
		Circle pizza3 = new Circle(1);
		System.out.println(pizza3.name);
		
		// 두 번째 객체 donut 만들기.
		// 레퍼런스 변수 donut 선언
		Circle donut;
		// Circle 객체 생성
		donut = new Circle();
		// 도넛 반지름 5로 설정
		donut.radius = 5;
		// 도넛 이름 "자바도넛"으로 변경
		donut.name = "자바도넛";
		//도넛 면적 계산하여 출력하기
		System.out.println(donut.getArea());
	}

}
