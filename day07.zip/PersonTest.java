package day07;

public class PersonTest {

	public static void main(String[] args) {
		// Person 객체 생성하기
		// 생성자 함수 → 인스턴스 생성
		Person hong = new Person(); // default 생성자
//		hong.name = "홍길동";
//		hong.age = 20;
//		hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("런닝");
		
		Person kim = new Person();
		kim.name = "김철수";
		kim.age = 25;
		kim.abc = 'B';
		kim.밥먹기();
		kim.운동하기("하키");
		
		// hong.addr = "대전동구 용운동";
		System.out.println(Person.getName()); // static 메소드 호출은 클래스 이름.으로 사용.
	}

}
