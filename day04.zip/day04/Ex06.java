package day04;

import java.util.Scanner;

public class Ex06 {


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int sum = 0;
		
		System.out.println("정수를 입력하세요.");

		// 5개 정수 입력 받아 양수의 합을 구하시오.
		for (int i = 0; i < 5; i++) {
			int num = sc.nextInt();
			if (num < 0) {
				continue;
			}
			sum += num;
		}
		
		System.out.println("양수의 합 : " + sum);
		
		sc.close();
	}

}