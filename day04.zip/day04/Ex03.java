package day04;
import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int balance = 10000;
		System.out.print("나이를 입력하시오 > ");
		int age = scan.nextInt();
		
		if(age >= 19) {
			balance -= 1200;
		}
		else if(age >= 13) {
			balance -= 720;
		}
		else if(age >= 7) {
			balance -= 450;
		}
		
		System.out.println("차감된 잔액 : " + balance);
		
		scan.close();
	}

}