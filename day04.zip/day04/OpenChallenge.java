package day04;
import java.util.Scanner;

public class OpenChallenge {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("가위 바위 보!");
		System.out.print("철수 > ");
		String RSP1 = scan.next();
		System.out.print("영희 > ");
		String RSP2 = scan.next();
		
		if(RSP1.equals(RSP2)) {
			System.out.println("비겼습니다!");
		}
		
		// 철수 가위
		else if(RSP1.equals("가위")) {
			if(RSP2.equals("바위")) {
				System.out.println("영희 승리!");
			}
			else {
				System.out.println("철수 승리!");
			}
		}
		
		// 철수 바위
		else if(RSP1.equals("바위")) {
			if(RSP2.equals("보")) {
				System.out.println("영희 승리!");
			}
			else {
				System.out.println("철수 승리!");
			}
		}
		
		// 철수 보자기
		else {
			if(RSP2.equals("가위")) {
					System.out.println("영희 승리!");
				}
			else {
				System.out.println("철수 승리!");
			}		
		}
		
		scan.close();
	}

}
