package day04;
import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		
		while (true) {
			int num = sc.nextInt();
			if (num < 0) {
				break;
			}
			sum += num;
		}

		System.out.println("양수의 합 : " + sum);
		
		sc.close();
	}

}
