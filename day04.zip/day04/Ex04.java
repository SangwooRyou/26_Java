package day04;

public class Ex04 {

	public static void main(String[] args) {
		
		// 1부터 10까지 합 계산 - for
		int sum = 0;
		
		for(int i=1; i<=10; i++) {
			sum += i;
		}
		
		System.out.println(sum);
	}

}
