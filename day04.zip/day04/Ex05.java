package day04;

public class Ex05 {

	public static void main(String[] args) {
		
		// 1부터 10까지의 합 계산 - while
//		int i = 1, sum = 0;
//		
//		while(i<=10) {
//			sum+=i;
//			i++;
//		}
//
//		System.out.println(sum);
		
		// do-while 버전 
		int i = 1, sum = 0;

		do {
			sum += i;
			i++;
		} while (i <= 10);

		System.out.println(sum);
	}
}
