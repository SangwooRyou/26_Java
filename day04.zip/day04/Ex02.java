package day04;
import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("필기시험 점수 입력 > ");
		int score = scan.nextInt();
		System.out.print("토익 점수 입력 > ");
		int TOEIC = scan.nextInt();
		
		if(score >= 80 && TOEIC >=850) {
			System.out.println("합격");
		}
		else {
			System.out.println("불합격");
		}
		
		scan.close();
	}

}
