package day10;
import java.util.Scanner;

public class HumanPlayer extends Player {
	public HumanPlayer(String name) {
		super(name);
	}

	public String turn() {
		System.out.print("가위 바위 보! ");
		
		Scanner sc = new Scanner(System.in);
		String human = sc.next();
		
		sc.close();
		return human;
	}
}
