package day10;

public abstract class Shape {
	
	
//	public void draw() {
//		System.out.println("도형을 그리다.");
//	}
	
	String name;
	
	abstract public void draw();
	
	public void printInfo() {
		System.out.println(name);
	}
}
