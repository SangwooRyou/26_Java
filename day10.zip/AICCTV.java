package day10;

class CCTV {
	private String resolution;
	
	public CCTV() {
		
	}

	public CCTV(String resolution) {
		this.resolution = resolution;
	}

	protected String getResolution() {
		return resolution;
	}
}

public class AICCTV extends CCTV {
	boolean faceCheck;
	public AICCTV(String resolution) {
		super(resolution);
	}
	
	public AICCTV(String resolution, boolean check) {
		super(resolution);
		this.faceCheck = check;
	}
	
	String re = super.getResolution();
	
	public void printInfo() {
		if(re.equals("FHD")){
			System.out.println("CCTV는 FHD급 해상도이며, 현재 얼굴 인식 작동 중");
		}
		else {
			System.out.println("해상도가 낮습니다.");
		}
	}

	public static void main(String[] args) {
		AICCTV ai = new AICCTV("FHD", true);
		ai.printInfo();
	}

}
