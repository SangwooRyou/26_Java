package day06;
import java.util.Scanner;

// 2개의 정수와 한 개의 문자열을 입력 받아 4칙 연산 수행 계산기 메소드.
	public class Method3 {
		public static int cal(int a, int b, String c) {
			int res = 0;
			
			switch(c) {
				case "+":
					res = a + b;
					break;
				case "-":
					res = a - b;
					break;
				case "*":
					res = a * b;
					break;
				case "/":
					if(b == 0) {res = 0;}
					else {
						res = a / b;						
					}
					break;
			}
			
			return res;
		}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String c = new String();
		
		System.out.println("정수 1에 -1 입력 시 종료.");
		boolean condition = true;
		
		while(condition) {			
			System.out.print("정수 1 입력 > ");
			int a = sc.nextInt();
			System.out.print("연산부호 입력 > ");
			c = sc.next();
			System.out.print("정수 2 입력 > ");
			int b = sc.nextInt();
			
			if(a == -1) {
				condition = false;
			}
			
			int result = cal(a, b, c);
			
			if(result == 0 && a != -1) {
				System.out.println("An error occured.");
			}
			else if(a == -1){
				break;
			}
			else {
				System.out.println(a +" " + c + " " + b + " = " + result);
			}
		}
		
		System.out.println("종료되었습니다.");
		
		sc.close();
	}

}
