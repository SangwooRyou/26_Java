package day06;
import java.util.Scanner;

public class Add {

	public static void main(String[] args) {
		// 2개 정수를 입력 받아서 더한 결과를 출력하시오.
		Scanner sc = new Scanner(System.in);
		
		int intNum1, intNum2, sum;
		
		System.out.print("정수 1 입력 > ");
		intNum1 = sc.nextInt();
		System.out.print("정수 2 입력 > ");
		intNum2 = sc.nextInt();
		
		sum = intNum1 + intNum2;
		System.out.println(intNum1 + " + " + intNum2 + " = " + sum);
		
		// 2개 실수를 입력 받아서 곱한 결과를 출력하시오.
		
		double doubleNum1, doubleNum2, multi;
		
		System.out.print("실수 1 입력 > ");
		doubleNum1 = sc.nextDouble();
		System.out.print("실수 2 입력 > ");
		doubleNum2 = sc.nextDouble();
		
		multi = doubleNum1 * doubleNum2;
		System.out.println(doubleNum1 + " x " + doubleNum2 + " = " + multi);
		
		sc.close();
	}

}
