package day06;

public class Overloading {
	// 메소드 오버로딩 : 메소드 이름은 같고, 매개변수의 개수와 타입은 다르게 정의
	// 블랙 커피
	public static void coffee(int coffee) {
		System.out.println("블랙 커피");
	}
	
	// 크림 커피
	public static void coffee(int coffee, int cream) {
		System.out.println("크림 커피");
		
	}
	
	// 믹스 커피
	public static void coffee(int coffee, int cream, int s) {
		System.out.println("믹스 커피");		
	}
	
	public static void main(String[] args) {
		coffee(3, 3, 3);
		coffee(3, 3);
		coffee(3);
	}

}
