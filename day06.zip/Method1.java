package day06;

import java.util.Scanner;

public class Method1 {
	// 1. 매개 변수도 없고, 반환형도 없는 add() 메소드
	public static void add() {
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자 1 입력 > ");
		int num1 = sc.nextInt();
		System.out.print("숫자 2 입력 > ");
		int num2 = sc.nextInt();
		int sum = num1 + num2;

		System.out.println("두 수의 합 : " + sum);
	}

	// 2. 매개 변수는 있고, 반환형은 없는 add() 메소드
	public static void add(int a, int b) {
		int sum = a + b;
		System.out.println(a + " + " + b + " = " + sum);
	}
	
	// 3. 매개 변수가 없고, 반환형이 있는 add1() 메소드
	public static int add1() {
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자 1 입력 > ");
		int num1 = sc.nextInt();
		System.out.print("숫자 2 입력 > ");
		int num2 = sc.nextInt();
		int sum = num1 + num2;

		return sum;
	}
	
	// 4. 매개 변수, 반환형이 모두 있는 메소드
	public static int add2(int a, int b) {
		int sum = a + b;
		return sum;
	}

	public static void main(String[] args) {
//		add();
//		add(3, 4);
//		System.out.println(add1());
		int result = add2(3, 4);
		System.out.println(result);
	}

}
