package day06;

import java.util.Scanner;

// 2개의 정수을 입력 받아 최대값을 반환하는 max 메소드 정의 후 호출.
	public class Method2 {
		public static int max(int a, int b) {
			int maxNum = a;
			if (b > a) {
				maxNum = b;
			}
	
			return maxNum;
		}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("정수 1 입력 > ");
		int a = sc.nextInt();
		System.out.print("정수 2 입력 > ");
		int b = sc.nextInt();

		int max = max(a, b);
		System.out.println("최대값 : " + max);
		
		sc.close();
	}

}
