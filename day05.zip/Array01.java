package day05;

import java.util.Scanner;

public class Array01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int intMax = 0;
		// 1차원 배열 선언
		int intArray[];

		// 배열 생성
		intArray = new int[5];

		// 배열 초기화 및 비교 (양수만 입력)
		for (int i = 0; i < intArray.length; i++) {
			System.out.print((i + 1) + "번째 배열 원소 입력 > ");
			intArray[i] = sc.nextInt();
			if (intArray[i] > intMax) {
				intMax = intArray[i];
			}
		}

		System.out.println("제일 큰 수는 " + intMax + "입니다.");
		
		sc.close();
	}
	
}
