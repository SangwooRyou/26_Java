package day05;

public class Array04 {

	public static void main(String[] args) {
		String str[] = {"사과", "바나나", "딸기", "복숭아", "포도"};
		
		// for-each 예제
//		for(String k:str) {
//			System.out.println(k);
//		}
		
		try {
			for(int i=0; i<6;i++) {
				System.out.println(str[i]);
			}
		} catch(ArrayIndexOutOfBoundsException a){
			a.printStackTrace();
		}
	}

}
