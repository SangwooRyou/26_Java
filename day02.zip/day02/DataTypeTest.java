package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1-1. 기본형 primitive 변수 선언.
		boolean isTrue;
		int age;
		double height, weight; // 같은 타입 여러 개 선언 -> ,로 구분.
		
		// 1-2. 기본형 변수 초기화
		isTrue = false;
		age = 20;
		height = 173.33; 
		weight = 55.5;
		
		// 2. 레퍼런스(참조)형 reference (배열, 클래스, 인터페이스)
		// String name = "RyouSangwoo"; - 미사용
		String s = new String("류상우"); 
		/*********************************************************** 
		원래는 이렇게 new와 함께 써야 함.
		단, String을 너무 많이 쓰기에 예외.
		***********************************************************/
		// DataTypeTest dtt = new DataTypeTest(); - 미사용
		
		String addr = new String("인천광역시 서구");
		
		// 3. 변수 값 출력하기
		System.out.println("isTrue 값 : "+isTrue);
		System.out.println("이름 : "+s);
		System.out.println("나이 : "+age);
		System.out.println("키 : "+height);
		System.out.println("몸무게 : "+weight);
		System.out.println("주소 : "+addr);
	}

}
