package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// print 계열 메소드를 이용해 자바로 하고 싶은 것.
		System.out.println("1. DB 연동 프로그램/웹 개발");
		System.out.print("2. 채팅 시스템 개발\n");
		System.out.println("3. MCP/API 연동해 보기");
		System.out.println("4. 외부 프로그램과 상호작용");
		System.out.print("5. Console에서 진행하는 CLI 게임 만들기");
	}

}
